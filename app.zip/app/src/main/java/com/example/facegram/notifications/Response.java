package com.example.facegram.notifications;

public class Response {
    private String success;
}
