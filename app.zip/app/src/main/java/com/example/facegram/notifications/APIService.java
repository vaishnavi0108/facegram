package com.example.facegram.notifications;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Headers;
import retrofit2.http.POST;

public interface APIService {
    @Headers({
            "Content-Type:application/json",
            "Authorization:key=AAAAituf9YY:APA91bGF-DM3nW4jtiK87HdlKljO6Fr8fM7wwT5ovttAtXinwNv08JPaIgkSuqEZt2ivyS1IEcNuOmcqQIINsJIAtqz2FiWyyt0HfezlmBBJxbc6qV99mUab1oR5rkbcDZfzSPxk6L3W"
    })

    @POST("fcm/send")
    Call<Response> sendNotification(@Body Sender body);
}
