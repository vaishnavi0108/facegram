import cv2
import numpy as np
from PIL import Image
import base64
import io
import face_recognition

def findEncodings(images):
    encodeList = []
    for img in images:
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        encode = face_recognition.face_encodings(img)[0]
        encodeList.append(encode)
    return encodeList

def main(testImage, firebaseStorage):
    # seperating uid and dp
    images = []
    className = ""
    
    all_files = firebaseStorage.child("Users_Profile_Cover_Imgs/").list_files()
    for file in all_files:
        currImg = cv2.imread(f'{firebaseStorage}/{file}')
        images.append(currImg)
        className = className + ", " + file

    return className
    
