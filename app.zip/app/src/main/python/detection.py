import cv2
import numpy as np
from PIL import Image
import base64
import io
import face_recognition

def main(data):
    decoded_data = base64.b64decode(data)
    np_data = np.fromstring(decoded_data, np.uint8)
    img = cv2.imdecode(np_data, cv2.IMREAD_UNCHANGED)

    img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)

    
    img_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    #finding face locations 
    faceLoc = face_recognition.face_locations(img_gray)
    if len(faceLoc)>0:
        return "OKAY"
    else:
        return "No face Detected. Please upload your picture!"



