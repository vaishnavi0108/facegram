from PIL import Image
import requests
from io import BytesIO
import cv2
import numpy
import face_recognition
import base64


# returning training images
def url_to_np(urls):
    images = []
    for url in urls:
        response = requests.get(url.strip())
        img = Image.open(BytesIO(response.content))
        opencvImage = cv2.cvtColor(numpy.array(img), cv2.COLOR_RGB2BGR)
        images.append(opencvImage)
    return images


# for training images
def findEncodings(images):
    encodeList = []
    for img in images:
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        encode = face_recognition.api.face_encodings(img)[0]
        encodeList.append((encode))

    return encodeList


# main
def main(testImage, myList):
    # separating uid and url
    users = myList.split("|")
    uids = []
    urls = []
    for i in range(len(users) - 1):
        uids.append(users[i].split(",")[0])
        urls.append(users[i].split(",")[1])

    images = url_to_np(urls)
    encodeListKnown = findEncodings(images)
    # return ((encodeListKnown))
    # finding faces in testImage
    decoded_data = base64.b64decode(testImage)
    np_data = numpy.fromstring(decoded_data, numpy.uint8)
    imgTest = cv2.imdecode(np_data, cv2.IMREAD_UNCHANGED)

    img_rgb = cv2.cvtColor(imgTest, cv2.COLOR_BGR2RGB)

    img_gray = cv2.cvtColor(imgTest, cv2.COLOR_BGR2GRAY)
    # finding face locations
    faceLoc = face_recognition.face_locations(img_gray)

    uid = ""
    # face recognition
    faceLoc = face_recognition.face_locations(img_gray)
    for face in range(len(faceLoc)):
        # print(face)
        encodeTest = face_recognition.face_encodings(img_rgb)[face]

        results = face_recognition.compare_faces(encodeListKnown, encodeTest)

        for matches in range(len(results)):
              if results[matches]:
                  uid = uid + uids[matches]+","

    return uid[:len(uid)-1]
